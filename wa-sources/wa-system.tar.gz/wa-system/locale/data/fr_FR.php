<?php

return array(
    'name' => 'Français',
    'region' => 'France',
    'english_name' => 'French',
    'english_region' => 'France'

);