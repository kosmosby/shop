<?php
class teamGroupDeleteConfirmAction extends teamGroupEditAction
{
}
