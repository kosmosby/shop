<?php
return array(
    'php' => array(
        'strict'  => true,
        'version' => '>=5.6.25',
    ),
    'app.installer'=>array(
        'version'=>'>=1.10.0',
        'strict'=>true,
    ),
);
//EOF