<?php

return array(
    'code' => 'PLN',
    'sign' => 'zł',
	'iso4217' => '985',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Polish złoty',
    'name' => array(
        'złoty',
    ),
    'frac_name' => array(
        'grosz',
    )
);