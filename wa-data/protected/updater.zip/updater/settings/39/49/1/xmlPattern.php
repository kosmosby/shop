<?php
return array(
    '/yml_catalog/shop/offers/offer'=> array (
        'dbArrKeyPath' =>'NONE',  // пишем для заглавного тега
        'pathAttrRead' => 'YES',
        'id'=>'product/id/id',
        'available' => 'product/available/available',
    ),
    '/yml_catalog/shop/offers/offer/vendorCode' => array (
        'dbArrKeyPath' => 'product/sku/sku',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/myseizes' => array (
        'dbArrKeyPath' => 'KEY',                     //ключ для массива базы данных
        'KEY'  => 'product/seize/myseizes',
    ),
    '/yml_catalog/shop/offers/offer/myseizes/value' => array (
        'dbArrKeyPath' => 'VALUE',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/sizes' => array (
        'dbArrKeyPath' => 'KEY',                     //ключ для массива базы данных
        'KEY'  => 'product/sizes/sizes',
    ),
    '/yml_catalog/shop/offers/offer/sizes/size' => array (
        'dbArrKeyPath' => 'VALUE',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/url' => array (
        'dbArrKeyPath' => 'product/url/url',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/price'=> array (
        'dbArrKeyPath' => 'product/price/price',                    //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/currencyId' => array (
        'dbArrKeyPath' => 'product/currency/currency',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/vat'=> array (
        'dbArrKeyPath' => 'product/vat/vat',
    ),
    '/yml_catalog/shop/offers/offer/categoryId'=> array (
        'dbArrKeyPath' => 'product/category_id/category_id',
    ),
    '/yml_catalog/shop/offers/offer/picture' => array (
        'dbArrKeyPath' => 'product/images/images',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/name' => array (
        'dbArrKeyPath' => 'product/name/name',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/description' => array (
        'dbArrKeyPath' => 'product/description/description',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/vendor' => array (
        'dbArrKeyPath' => 'product/vendor/vendorSup',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/offers/offer/weight' => array (
        'dbArrKeyPath' => 'product/weight/weightSup',                     //ключ для массива базы данных
    ),
    '/yml_catalog/shop/categories/category'=> array (
        'dbArrKeyPath' => 'category/name/name', //!!!ВОТ ЭТУ ХРЕНЬ ВСТАВЛЯЕМ ДЛЯ ФОРМИРОВАНИЯ КАТАЛОГА!!!
        'pathAttrRead' => 'YES',
        'id'=>'category/id/id',
        'parentId' => 'category/parent_id/parent_id',
    ),
);