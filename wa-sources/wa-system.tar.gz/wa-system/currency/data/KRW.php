<?php

return array(
    'code' => 'KRW',
    'sign' => '₩',
	'iso4217' => '410',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'South Korean won',
    'name' => array(
        'won',
    ),
    'frac_name' => array(
        'jeon',
    )
);