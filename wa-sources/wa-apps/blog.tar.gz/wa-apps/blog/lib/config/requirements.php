<?php

return array(
	'app.installer' => array(
		'version' => '>=1.8.2',
		'strict' => true
	),
);
